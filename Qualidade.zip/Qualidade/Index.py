import unittest
from seu_modulo import etBcb

class TestEtBcb(unittest.TestCase):
    def setUp(self):
        self.api = etBcb("https://api.bcb.gov.br/dados/serie/bcdata.sgs.11/dados/ultimos/10?formato=json")

    def test_requisicao_api(self):
        self.api.requisicao_api()
        self.assertIsNotNone(self.api.dados)

    def test_transformar_dados(self):
        self.api.requisicao_api()
        self.api.transformar_dados("value")
        self.assertIsNotNone(self.api.df)

if __name__ == '__main__':
    unittest.main()
