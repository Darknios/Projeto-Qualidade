url = "https://olinda.bcb.gov.br/olinda/servico/MPV_DadosAbertos/versao/v1/odata/Quantidadeetransacoesdecartoes(trimestre=@trimestre)?@trimestre=''&$top=10000&$format=json&$select=trimestre,nomeBandeira,nomeFuncao,produto,qtdCartoesEmitidos,qtdCartoesAtivos,qtdTransacoesNacionais,valorTransacoesNacionais,qtdTransacoesInternacionais,valorTransacoesInternacionais"

# Instanciar a classe ETL com o link da API
etl = etBcb(url)

# Executar o método de requisição para extrair os dados da API
etl.requisicao_api()

etl.transformar_dados('value')

etl.salvar_sqlite('transacaoCartao')

etl.salvar_csv('transacaoCartao.csv')